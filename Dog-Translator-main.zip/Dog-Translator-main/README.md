# Dog-Translator
 <p>Used API to translate English Language to Dogs Language.</p>
 <p>Tech Stack : VanillaJS, HTML and CSS.</p>
 
 Preview :![screencapture-dog-language-translator-netlify-app-2022-10-25-21_21_13](https://user-images.githubusercontent.com/49878564/197821821-e3739235-809c-479c-8a59-68ba998b1d88.png)

Project link : https://dog-language-translator.netlify.app/
 
